# ======================================================================
# Title: To do dictionary list
# Created by: Anthony Suk
# Created Date: 11/5/2018
# Updated: 11/10/2018
# Description: This script creates a Python dictionary file file
# containing a task and it's priority and allow a user to add, remove,
# display and/or save the data to file.
# ======================================================================
# Pseudo code
# -------------
# Create a text file called Todo.txt using the following data:
# Clean House,low
# Pay Bills,high
# todo = {"Clean house": "low","Pay bills":"high"}
# When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.
# use a for loop to read a single line of text from the file and then place the data into a new dictionary object.

todofile = open("C:\_PythonClass\Assignment05\Todo.txt", "r")
dict = {}
for line in todofile:
    x = line.split(",")
    task = x[0]
    priority = x[1]
    dict[task] = priority

# After you get the data in a Python dictionary, Add the new dictionary “row” into a Python list
# object (now the data will be managed as a table).

todolistVal = str(dict.values())
todolistTsk = str(dict.keys())

# Display the contents of the List to the user.

print("Tasks:", dict.keys(), "Priorities", dict.values())

# Allow the user to Add or Remove tasks from the list using numbered choices.

option = None
while option != "5":
    print(
        """
 Menu of Options
 1-Show current data.
 2-Add a new item.
 3-Remove an existing item.
 4-Save data to file
 5-Exit the program
 """
    )

    option = input("Option:")
    print()
    if option == "5":
        print("Good-bye.")
# Show current data
    elif option == "1":
        print("Current Tasks:", dict.keys(), "Priorities", dict.values())
# Add a new task
    elif option == "2":
        term = input("What task would you like to add?:")
        if term not in dict:
            priority = input("\nWhat is the new task's priority?:")
            dict[term] = priority
            print("\n", term, "has been added.")
        else:
            print("\nThat task already exists!")

# Remove an existing task
    elif option == "3":
        task = input("What tasks would you like to remove?:")
        if task in dict:
            del dict[task]
            print("\nOK,", task, " has been deleted!")
        else:
            print("\nNo can do,", task, " does not exist!")

# Save data to a file
    elif option=="4":
        savetofile = input("do you want to save data to a file?(y/n): ")
        if (savetofile.lower() == 'y'):
            objF = open("C:\_PythonClass\Assignment05\Todo.txt", "a")
            objF.write(str(dict))
            objF.close()
            print("Data has been saved to file")
    # Unknown option picked
    else:
        print("\nSorry but ", option, " is not an option!")
input("\n\nPress any key to exit.")




