#------------------------------------------------- #
# Title: Working with Functions
# Created by: Anthony Suk
# Created Date: Nov. 10, 2018
# Description: This script uses the Todo.txt file
# and recodes the Module 5 assignment using functions
# this time for portability.
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file (todofile)
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

#strData = ""
#dicRow = {}
#lstTable = []

# todofile = open("C:\_PythonClass\Assignment06\Todo.txt", "r")
todofile = open("C:\_PythonClass\Assignment05\Todo.txt", "r")
dict = {}
for line in todofile:
    x = line.split(",")
    task = x[0]
    priority = x[1]
    dict[task] = priority

todolistVal = str(dict.values())
todolistTsk = str(dict.keys())

#todofile = open("C:\_PythonClass\Assignment06\Todo.txt", "r")
#for line in todofile:
#   strData = line.split(",")
#   dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
#   lstTable.append(dicRow)
#todofile.close()


# Display a menu of choices to the user
def menu_choice():
    option = None
    while option != "5":
        print(
        """
    Menu of Options
    1-Show current data.
    2-Add a new item.
    3-Remove an existing item.
    4-Save data to file
    5-Exit the program
    """
    )
    print("Choose an option: ")
    option = input("Option:")
    print()
    if option == "5":
        print("Good-bye.")
    return option

# Function to Display all todo items to user
def menu_choice1():
    if option == "1":
        print("Current Tasks:", dict.keys(), "Priorities", dict.values())
    else:
        return

# Function to Add a new item to the list/Table


def menu_choice2():
    if option == "2":
        term = input("What task would you like to add?:")
        if term not in dict:
            priority = input("\nWhat is the new task's priority?:")
            dict[term] = priority
            print("\n", term, "has been added.")
        else:
            print("\nThat task already exists!")
    return


# Function to Remove a new item to the list/Table
def menu_choice3():
    if option == "3":
        task = input("What tasks would you like to remove?:")
        if task in dict:
            del dict[task]
            print("\nOK,", task, " has been deleted!")
        else:
            print("\nNo can do,", task, " does not exist!")
    return


# Function to Save data to a file
def menu_choice4():
    if option == "4":
        savetofile = input("do you want to save data to a file?(y/n): ")
        if (savetofile.lower() == 'y'):
            objF = open("C:\_PythonClass\Assignment05\Todo.txt", "a")
            objF.write(str(dict))
            objF.close()
            print("Data has been saved to file")
        else:
            print("Data will not be saved.")


# Main function
def main():
    option = []
    menu_choice()
    while Option != "5":
        if option == 1:
            menu_choice1()
        elif option ==2:
            menu_choice2()
        elif option == 3:
            menu_choice3()
        elif option == 4:
            menu_choice4()
        elif option == "5":
            print("Good-bye.")
    return option